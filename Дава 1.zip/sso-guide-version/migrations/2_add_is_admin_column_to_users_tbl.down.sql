ALTER TABLE users DROP COLUMN is_admin;
