# sso

Protobuf contract: https://github.com/GolangLessons/protos
